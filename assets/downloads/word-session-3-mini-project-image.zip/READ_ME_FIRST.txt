Word Session 3 Mini Project Image Resource

How to use this file:
1. Right-click this ZIP file after downloading.
2. Choose Extract All... or Extract Here.
3. Open the extracted folder.
4. Insert word-session-3-mini-project-image.png into Microsoft Word.

Watch Word Session 3 before doing the assignment:
https://youtu.be/Fr0np3nukWg
